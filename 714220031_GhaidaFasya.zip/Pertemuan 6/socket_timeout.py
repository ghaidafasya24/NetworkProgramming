# Ghaida Fasya Yuthika Afifah
# D4TI-2B
# 714220031

import socket

# Tujuan: Menunjukkan cara mengatur dan mendapatkan timeout socket default.

# Langkah-langkah:
# 1. Membuat socket menggunakan modul socket.
# 2. MEngatur timeout socket dengan menggunakan metode settimeout().
# 3. Mendapatkan timeout socket saat ini menggunakan gettimeout().

def set_socket_timeout(sock, timeout):
     """
     Mengatur timeout socket.
    
     Args:
         sock: Objek socket.
         timeout: Timeout dalam detik.
     """
     sock.settimeout(timeout)
def get_socket_timeout(sock):
     """
     Mendapatkan timeout socket saat ini.
    
     Args:
         sock: Objek socket.
        
     Returns:
         Timeout saat ini dalam detik.
     """
     return sock.gettimeout()

 # Contoh penggunaan
if __name__ == "_main_":
     s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
     set_socket_timeout(s, 10)  # Mengatur timeout menjadi 10 detik
     print(f"Timeout saat ini: {get_socket_timeout(s)} detik")