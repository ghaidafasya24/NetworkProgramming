# Ghaida Fasya Yuthika Afifah
# D4TI-2B
# 714220031

import socket

# Tujuan: Menunjukkan cara mengatur ukuran buffer pengiriman dan penerimaan socket.

# Langkah-langkah:
# 1. Membuat socket menggunakan modul socket.
# 2. Mengatur ukuran buffer pengiriman menggunakan setsockopt() dengan SO_SNDBUF.
# 3. Mengatur ukuran buffer penerimaan menggunakan setsockopt() dengan SO_RCVBUF.
# 4. Mendapatkan ukuran buffer pengiriman dan penerimaan saat ini menggunakan getsockopt().

def set_send_buffer_size(sock, size):
    """
    Mengatur ukuran buffer pengiriman socket.
    
    Args:
        sock: Objek socket.
        size: Ukuran buffer dalam bytes.
    """
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, size)

def set_receive_buffer_size(sock, size):
    """
    Mengatur ukuran buffer penerimaan socket.
    
    Args:
        sock: Objek socket.
        size: Ukuran buffer dalam bytes.
    """
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, size)

def get_send_buffer_size(sock):
    """
    Mendapatkan ukuran buffer pengiriman saat ini.
    
    Args:
        sock: Objek socket.
        
    Returns:
        Ukuran buffer pengiriman saat ini dalam bytes.
    """
    return sock.getsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF)

def get_receive_buffer_size(sock):
    """
    Mendapatkan ukuran buffer penerimaan saat ini.
    
    Args:
        sock: Objek socket.
        
    Returns:
        Ukuran buffer penerimaan saat ini dalam bytes.
    """
    return sock.getsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF)


if __name__ == "_main_":
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    set_send_buffer_size(s, 8000)  # Mengatur ukuran buffer pengiriman menjadi 8 KB
    set_receive_buffer_size(s, 8000)  # Mengatur ukuran buffer penerimaan menjadi 8 KB
    print(f"Ukuran buffer pengiriman: {get_send_buffer_size(s)} bytes")
    print(f"Ukuran buffer penerimaan: {get_receive_buffer_size(s)} bytes")