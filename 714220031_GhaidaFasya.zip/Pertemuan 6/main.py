# Ghaida Fasya Yuthika Afifah
# D4TI-2B
# 714220031

import socket
import socket_timeout
import socket_errors
import socket_buffer

def main():
    # A. Mengatur dan Mendapatkan Default Socket Timeout
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    socket_buffer.set_send_buffer_size(s, 8000)  # Mengatur ukuran buffer pengiriman menjadi 8 KB
    socket_buffer.set_receive_buffer_size(s, 8000)  # Mengatur ukuran buffer penerimaan menjadi 8 KB
    print("c. Ukuran buffer sebelum dan sesudah modifikasi")
    send_buffer_before = socket_buffer.get_send_buffer_size(s)
    receive_buffer_before = socket_buffer.get_receive_buffer_size(s)
    print(f"Ukuran buffer pengiriman sebelum modifikasi: {send_buffer_before} bytes")
    print(f"Ukuran buffer penerimaan sebelum modifikasi: {receive_buffer_before} bytes")

    # B. Menangani Socket Errors
    print("b. Informasi tentang status koneksi")
    try:
        socket_errors.handle_socket_errors()
    except socket.error as err:
        print(f"Terjadi kesalahan socket: {err}")
    print("\n")

    # C. Memodifikasi Ukuran Buffer Pengiriman/Penerimaan Socket
    print("c. Ukuran buffer sebelum dan sesudah modifikasi")
    socket_buffer.set_send_buffer_size(s, 8192)  # Atur ukuran buffer pengiriman menjadi 8 KB
    socket_buffer.set_receive_buffer_size(s, 8192)  # Atur ukuran buffer penerimaan menjadi 8 KB
    send_buffer_after = socket_buffer.get_send_buffer_size(s)
    receive_buffer_after = socket_buffer.get_receive_buffer_size(s)
    print(f"Ukuran buffer pengiriman setelah modifikasi: {send_buffer_after} bytes")
    print(f"Ukuran buffer penerimaan setelah modifikasi: {receive_buffer_after} bytes")
    s.close()

if __name__ == "_main_":
    main()  