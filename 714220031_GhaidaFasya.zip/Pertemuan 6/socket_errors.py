# Ghaida Fasya Yuthika Afifah
# D4TI-2B
# 714220031

import socket

# Tujuan: Menunjukkan cara menangani kesalahan socket saat terjadi.

# Langkah-langkah:
# 1. Buat socket menggunakan modul socket.
# 2. Cobalah melakukan operasi yang mungkin memunculkan kesalahan socket.
# 3. Tangani kesalahan socket dengan menggunakan blok try-except.
# 4. Pastikan untuk menutup socket setelah selesai.

# def handle_socket_errors():
#     """
#     Menangani kesalahan socket saat terjadi.
#     """
#     try:
#         # melakukan operasi socket yang mungkin memunculkan kesalahan
#         # menghubungkan ke server yang tidak aktif
#         s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#         s.connect(("example.com", 80))
#     except socket.error as err:
#         print(f"Terjadi kesalahan socket: {err}")
#     finally:
#         s.close()

# # Contoh penggunaan
# if _name_ == "_main_":
#     handle_socket_errors()

def handle_socket_errors():
    """
    Menangani kesalahan socket saat terjadi.
    """
    try:
        # Mencoba melakukan operasi socket yang mungkin memunculkan kesalahan
        # Contoh: Menghubungkan ke server yang tidak aktif
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect(("example.com", 80))
    except socket.error as err:
        print(f"Terjadi kesalahan socket: {err}")
    finally:
        s.close()
    
    # Pesan di luar blok try-except untuk kasus tanpa kesalahan
    print("Operasi socket selesai tanpa kesalahan")

# Contoh penggunaan
if __name__ == "_main_":
    handle_socket_errors()